var searchData=
[
  ['voting_5feval',['voting_eval',['../Voting_8h.html#aa2785b1944d00fcff7e2f100805ae532',1,'Voting.h']]],
  ['voting_5fprint',['voting_print',['../Voting_8h.html#a95f6f52c9364035f979f0fe0ee200f91',1,'Voting.h']]],
  ['voting_5fread',['voting_read',['../Voting_8h.html#a85e458c3aedce5c3c8c18eb05516da29',1,'Voting.h']]],
  ['voting_5fsolve',['voting_solve',['../Voting_8h.html#aa8cb9e37e77cb6bf19da7caccc864b29',1,'Voting.h']]]
];
